export const GameListTypes = [
    {name:"In House",id:0},
    {name:"Third Party",id:1}
]

// this is just copy  enquirydetails 

{/* <View style={styles.rowContainer}>
		
<Text style={[styles.desc, { fontWeight: 'bold', fontSize: 16 }]}>Event :-</Text>
<Text style={styles.desc}>Date: {showDateAsClientWant(eventDetails?.event_date)}</Text>
<Text style={styles.desc}>Time: {showTimeAsClientWant(eventDetails?.event_start_time)} - {showTimeAsClientWant(eventDetails?.event_end_time)}</Text>

<Text style={styles.desc}>
    Play Time: {eventDetails?.play_time}
</Text>

<Text style={[styles.desc, { fontWeight: 'bold',fontSize: 16, marginTop: 10 }]}>Setup :-</Text>
<Text style={styles.desc}>Date: {showDateAsClientWant(eventDetails?.setup_date)}</Text>
<Text style={styles.desc}>Time: {showTimeAsClientWant(eventDetails?.setup_start_time)}</Text>


<Text style={[styles.desc, { marginTop: 10 }]}>
    # of Guest: {eventDetails?.num_of_guest}
</Text>
<Text style={styles.desc}>
    # of Kids: {eventDetails?.num_of_kids}
</Text>

<Text style={styles.desc}>
    Event Type: {eventDetails?.event_type_name}
</Text>

</View>



// venue
<View style={styles.rowContainer}>
		
        <Text style={styles.desc}>
            Venue: {eventDetails?.venue}
        </Text>
        <Text style={styles.desc}>
            Address: {eventDetails?.address}
        </Text>
        <Text style={styles.desc}>
            Landmark: {eventDetails?.landmark}
        </Text>
        <Text style={styles.desc}>
            Which Floor is the setup?: {eventDetails?.floor_name}
        </Text>
        <Text style={styles.desc}>
            Google Location: {eventDetails?.google_location}
        </Text>
    </View> */}